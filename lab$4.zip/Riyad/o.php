<?php

	if( isset($_POST['submit'])){
		
		if($_POST['name'] == ""){
			echo "Null found!";
		}else{
		 	echo $_POST['name'];
		 	echo '<br>';
		}


		if($_POST['email'] == ""){
			echo "Null found!";
		}else{
		 	echo $_POST['email'];
		 	echo '<br>';
		}



		if($_POST['gender'] == ""){
			echo "Null found!";
		}else{
		 	echo $_POST['gender'];
		 	echo '<br>';
		}

		if($_POST['dob1'] == ""){
			echo "Null found!";
		}else{
		 	echo $_POST['dob1'];
		 	echo '<br>';
		}


		if($_POST['dob2'] == ""){
			echo "Null found!";
		}else{
		 	echo $_POST['dob2'];
		 	echo '<br>';
		}


		if($_POST['dob3'] == ""){
			echo "Null found!";
		}else{
		 	echo $_POST['dob3'];
		 	echo '<br>';
		}


		if($_POST['bg'] == ""){
			echo "Null found!";
		}else{
		 	echo $_POST['bg'];
		 	echo '<br>';
		}

		
		
		

		
	}
	
?>