<?php 

	// echo "Hellow PHP";

	// echo "<br/>";

	// $A =  print('Hello php');

	// echo $A


	for($i=0; $i<10; $i++)
	{
		echo 'Riyad'.'<br>';
	}






 ?>