
<!DOCTYPE html>
<html>
<head>
	<title>lab_task_1</title>
</head>
<body>
<center>

<form method='POST' action='o.php'>
<table border="1" width='50%' style="padding:0; margin:0;">

	<tr>
		<td colspan="3" >
			<center>
			<h3>Person Profile</h3>
			</center>
		</td>
	</tr>

	<tr>
		<td width="20%">Name</td>
		<td width="70%"><input type="text" name="name"></td>
		<td></td>
	</tr>

	<tr>
		<td width="20%">Email</td>
		<td width="70%"><input type="text" name="email"></td>
		<td></td>
	</tr>


	<tr>
		<td width="20%">Gender</td>
		<td width="70%">
			<input type="radio" name="gender"> Male
			<input type="radio" name="gender"> Female
			<input type="radio" name="gender"> Other


		</td>
		<td></td>
	</tr>

	<tr>
		<td width="20%">Date of Birth</td>
		<td width="70%">
			<input type="number" name="dob1" style="width: 40px;" > /
			<input type="number" name="dob2" style="width: 40px;" > /
			<input type="number" name="dob3" style="width: 40px;" >  <i>(dd/mm/yyyy)</i>


		</td>
		<td></td>
	</tr>

	<tr>
		<td width="20%">Blood Group</td>
		<td width="70%">
			<select name="bg">
				<option>A+</option>
				<option>B+</option>
			</select>

		</td>
		<td></td>
	</tr>


	<tr>
		<td width="20%">Degree</td>
		<td width="70%">
			<input type="checkbox" name="deg1" " > SSC
			<input type="checkbox" name="deg2" " > HSC
			<input type="checkbox" name="deg3" " > BSc.
			<input type="checkbox" name="deg4" " > MSc.

		</td>
		<td></td>
	</tr>


	<tr>
		<td width="20%">Photo</td>
		<td width="70%"><input type="file" name=""></td> 
		<td></td>
	</tr>

	<tr>
		<td colspan="3" height="40px">
			<center>
			
			</center>
		</td>
	</tr>

	<tr>
		<td colspan="3" height="40px" style="text-align: right;">
		
			<input type="submit" name="submit">
			<input type="reset" name="reset">

		</td>
	</tr>


</table>
</form>
</center>
</body>
</html>